#ifndef WEB_H
#define WEB_H

void setupWebServer();

#endif